package ru.levelp.at.homework2;


import static ru.levelp.at.homework2.HappyTicket.getHappyTicket;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class HappyTicketPositiveTest {

    @Test
    public void getHappyTicketTestPositivTest() {
        int x = 100100;
        Assertions.assertTrue(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketTestPositiv1Test() {
        int x = 999999;
        Assertions.assertTrue(getHappyTicket(x));

    }
}
