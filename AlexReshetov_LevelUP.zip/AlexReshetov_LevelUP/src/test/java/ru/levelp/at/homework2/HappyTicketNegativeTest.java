package ru.levelp.at.homework2;

import static ru.levelp.at.homework2.HappyTicket.getHappyTicket;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;




public class HappyTicketNegativeTest {

    @Test
    public void getHappyTicketNegativTest() {
        int x = -9;
        Assertions.assertFalse(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketNegativ2Test() {
        int x = 4567888;
        Assertions.assertFalse(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketNegativ3Test() {
        int x = 100;
        boolean actual = getHappyTicket(x);
        boolean expected = false;
        Assertions.assertFalse(actual);

    }

    @Test
    public void getHappyTicketNegativ4Test() {
        int x = 100;
        boolean actual = getHappyTicket(x);
        int expected = 0;
        if (!actual) {
            expected = 1;
        }
        Assertions.assertEquals(expected, 1);
    }

}
