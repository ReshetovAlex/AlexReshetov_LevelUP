package ru.levelp.at.homework2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static ru.levelp.at.homework2.HappyTicket.getHappyTicket;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class HappyTicketTest {

    @Test
    public void getHappyTicketTestPositivTest() {
        int x = 100100;
        assertTrue(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketTestPositiv1Test() {
        int x = 999999;
        assertTrue(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketNegativTest() {
        int x = -9;
        assertFalse(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketNegativ2Test() {
        int x = 4567888;
        assertFalse(getHappyTicket(x));

    }

    @Test
    public void getHappyTicketNegativ3Test() {
        int x = 100;
        boolean actual = getHappyTicket(x);
        boolean expected = false;
        assertFalse(actual);

    }

    @Test
    public void getHappyTicketNegativ4Test() {
        int x = 100;
        boolean actual = getHappyTicket(x);
        int expected = 0;
        if (!actual) {
            expected = 1;
        }
        assertEquals(expected, 1);
    }

}
