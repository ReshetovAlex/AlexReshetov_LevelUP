package ru.levelp.at.homework2;

public class HappyTicket {
    public static boolean getHappyTicket(int ticket) {
        //bilet = 100001;
        boolean happyTicketCheck;
        int sumFirstHalf;
        int sumSecondHalf;
        if ((ticket < 1000000) && (ticket > 99999)) {
            int x6 = ticket / 100000;
            int x5 = ticket % 100000 / 10000;
            int x4 = ticket % 10000 / 1000;
            int x3 = ticket % 1000 / 100;
            int x2 = ticket % 100 / 10;
            int x1 = ticket % 10;
            sumFirstHalf = x6 + x5 + x4;
            sumSecondHalf = x3 + x2 + x1;
            if (sumFirstHalf == sumSecondHalf) {
                happyTicketCheck = true;
                // System.out.println("Билет счатливый");
            } else {
                happyTicketCheck = false;
                System.out.println("Билет не счастливый, суммы половинок не равны");
            }
        } else {
            happyTicketCheck = false;
            //System.out.println("Билет не счастливый");
        }
        return happyTicketCheck;
    }
}
